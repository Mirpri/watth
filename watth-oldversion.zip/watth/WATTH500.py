import pygame
import pygame.freetype
import sys
def bcolor():
    global white
    global gray
    global lgray
    global llgray
    global lred
    global red
    global wat
    global lwat
    global swat
    global hwat
    global black
    global tcd1
    global tcl1
    global tcd2
    global tcl2
    global tcd3
    global tcl3
    white=250,250,250
    gray=140,140,140
    lgray=240,240,240
    llgray=245,245,245
    lred=255,230,230
    red=200,0,0
    wat=0,100,120
    lwat=210,242,240
    swat=100,0,90
    hwat=242,210,130
    black=0,0,0
    tcd1=wat
    tcl1=lwat
    tcd2=wat
    tcl2=lwat
    tcd3=wat
    tcl3=lwat
bcolor()


pygame.init()
screencaption=pygame.display.set_caption("Watth500")
screen=pygame.display.set_mode([600,320])
screen.fill((white))

f1=pygame.freetype.Font(r"C:\Windows\Fonts\msyh.ttc",36)
f2=pygame.freetype.Font(r"C:\Windows\Fonts\trebuc.ttf",36)
f2.render_to(screen,[160,110],"Watth",(wat),size=90)
f2.render_to(screen,[165,115],"Watth",(190,232,237,180),size=90)
pygame.display.update()
import random
import math
from pygame.locals import *
import time
time.sleep(1)
m=0
t=0
mode=0
def dcbtn(sx,sy,lenth,color,txt,tcolor,sk):
    l1=lenth//4
    x1=sx
    x2=sx
    while l1:
        pygame.draw.circle(screen,(color),[x1,sy],13,0)
        
        pygame.display.update()
        time.sleep(0.005)
        x1+=4
        l1-=1
    l1=lenth//4
    x1=sx
    x2=sx
    while l1:
        pygame.draw.circle(screen,(white),[x1,sy],10,0)
        
        pygame.display.update()
        time.sleep(0.005)
        x1+=4
        l1-=1
    f1.render_to(screen,[sx+sk,sy-8],str(txt),(tcolor),size=16)
    pygame.display.update()
def rare(x,y,color,lenth,width,r):
    pygame.draw.circle(screen,(color),[x+r,y+r],r,0)
    pygame.draw.circle(screen,(color),[x+lenth-r,y+width-r],r,0)
    pygame.draw.circle(screen,(color),[x+lenth-r,y+r],r,0)
    pygame.draw.circle(screen,(color),[x+r,y+width-r],r,0)
    pygame.draw.rect(screen, (color), [x+r,y,lenth-(2*r),width], 0)
    pygame.draw.rect(screen, (color), [x,y+r,lenth,width-(2*r)], 0)
def raref(x,y,color,lenth,width,r,th):
    rare(x,y,color,lenth,width,r)
    rare(x+th,y+th,white,lenth-2*th,width-2*th,r)
def ifinput():
    global t
    global count
    if event.key==pygame.K_RETURN:
        count-=1
    if event.key==pygame.K_BACKSPACE:
        t=t//10 
        dysz()
    if event.key == pygame.K_1:
        t=10*t+1
        dysz()
    if event.key == pygame.K_2:
        t=10*t+2
        dysz()
    if event.key == pygame.K_3:
        t=10*t+3
        dysz()
    if event.key == pygame.K_4:
        t=10*t+4
        dysz()
    if event.key == pygame.K_5:
        t=10*t+5
        dysz()
    if event.key == pygame.K_6:
        t=10*t+6
        dysz()
    if event.key == pygame.K_7:
        t=10*t+7
        dysz()
    if event.key == pygame.K_8:
        t=10*t+8
        dysz()
    if event.key == pygame.K_9:
        t=10*t+9
        dysz()
    if event.key == pygame.K_0:
        t=10*t+0
        dysz()
def iptbox(color,lenth):
    xc=180
    count=lenth//2
    while count:
        pygame.draw.circle(screen,(lgray),[xc,37],15,0)
        pygame.display.update()
        time.sleep(0.003)
        xc+=2
        count-=1
    count=35
    while count:
        pygame.draw.circle(screen,(color),[xc,37],15,0)
        
        pygame.display.update()
        time.sleep(0.003)
        xc+=2
        count-=1
    pygame.draw.rect(screen, (lgray), [180,22,lenth,30], 0)
    f1.render_to(screen,[200+lenth,33],"确认",(black),size=15)
    pygame.display.update()
def bgrc(color):
    count=random.randint(3,10)
    while count:
        pygame.draw.circle(screen,(color),[random.randint(0,600),random.randint(0,300)],random.randint(50,100),0)
        count-=1
def home():
    screen.fill((white))
    bgrc(lwat)
    f1.render_to(screen,[100,20],"欢迎来到",(wat),size=30)
    f2.render_to(screen,[250,20],"Watth",(wat),size=40)
    rare(0,280,lgray,600,100,0)
    f1.render_to(screen,[550,290],"退出",(swat),size=18)
    f1.render_to(screen,[490,290],"关于",(gray),size=18)
    f1.render_to(screen,[430,290],"选项",(gray),size=18)

    raref(50, 80,tcl1,150,180,10,3)
    raref(225,80,tcl2,150,180,10,3)
    raref(400,80,tcl3,150,180,10,3)
    f1.render_to(screen,[70,100],"数字x-ray",(tcd1),size=22)
    f1.render_to(screen,[70,150],"质因数分解",(tcd1),size=15)
    f1.render_to(screen,[70,170],"化简平方根",(tcd1),size=15)
    f1.render_to(screen,[245,100],"计算面积",(tcd2),size=22)
    f1.render_to(screen,[245,150],"输入坐标",(tcd2),size=15)
    f1.render_to(screen,[245,170],"求三角形面积",(tcd2),size=15)
    f1.render_to(screen,[420,100],"一次函数",(tcd3),size=22)
    f1.render_to(screen,[420,150],"输入两点坐标",(tcd3),size=15)
    f1.render_to(screen,[420,170],"求解析式",(tcd3),size=15)

    mode=0
    pygame.display.update()

#主循环
while True:
    
    if mode==0:
        home()
        count=1
        while count:
            for event in pygame.event.get():
                if event.type == QUIT:
                    exit()
                if event.type == KEYDOWN:
                    if event.key==pygame.K_q:
                        mode=1
                        count-=1
                    if event.key==pygame.K_w:
                        mode=2
                        count-=1
                    if event.key==pygame.K_e:
                        mode=3
                        count-=1
                    if event.key==pygame.K_ESCAPE:
                        sys.exit()
                if event.type == pygame.MOUSEBUTTONUP:
                    mx,my=pygame.mouse.get_pos()
                    if 50<mx<200 and 80<my<260:
                        mode=1
                        count-=1
                    if 225<mx<375 and 80<my<260:
                        mode=2
                        count-=1 
                    if 400<mx<550 and 80<my<260:
                        mode=3
                        count-=1 
                    if 540<mx<600 and 280<my<320:
                        sys.exit()
                    if 480<mx<535 and 280<my<320:
                        mode=0
                        count-=1
                    if 420<mx<475 and 280<my<320:
                        mode=0.1
                        count-=1
    
    if mode==0.1:
        screen.fill((white))
        f1.render_to(screen,[50,40],"选择主题",(wat),size=20)
        dcbtn(200,50,50,lgray,"彩色",gray,5)
        dcbtn(300,50,50,lgray,"黑暗",gray,5)
        dcbtn(400,50,50,lgray,"默认",gray,5)

        pygame.display.update()
        count=2
        while count>1:
            for event in pygame.event.get():
                if event.type == QUIT:
                    exit()
                if event.type == pygame.MOUSEBUTTONUP:
                    mx,my=pygame.mouse.get_pos()
                    if 200<mx<250 and 35<my<65:
                        bcolor()
                        tcd1=100,140,140
                        tcl1=210,240,240
                        tcd2=100,100,140
                        tcl2=210,210,240
                        tcd3=140,100,140
                        tcl3=240,210,240
                        count-=1
                    if 300<mx<350 and 35<my<65:
                        bcolor()
                        tcd1=lwat
                        tcl1=wat
                        tcd2=lwat
                        tcl2=wat
                        tcd3=lwat
                        tcl3=wat
                        lgray=100,100,100
                        lred=150,50,50
                        gray=240,240,240
                        wat=lwat
                        lwat=0,90,100
                        black=white
                        white=0,0,0
                        count-=1
                    if 400<mx<450 and 35<my<65:
                        bcolor()
                        count-=1
    if mode==0:
        screen.fill((white))
        f2.render_to(screen,[100,50],"Watth",(wat),size=20)
        f1.render_to(screen,[100,100],"版本:    500(Simplified Chinese)",(wat),size=17)
        f1.render_to(screen,[100,150],"发布日期:    2020.7.17",(wat),size=17)
    if mode==1:  
        screen.fill((white))
        bgrc(tcl1)
        f1.render_to(screen,[500,280],"Watth",(tcd1),size=20)
        t=0
        
        x=2
        y=0
        z=1
        xz=1
        m=2
        n=0
        p=0
        q=0
        xc=180
        count=65
        raref(50,30,tcl1,500,250,20,5)
        
        f1.render_to(screen,[130,70],"输入数字",(black),size=25)
        f1.render_to(screen,[130,105],"然后得到几乎一切你期待的关于此数字的数学信息",(black),size=15)
        f1.render_to(screen,[130,170],"——————",(black),size=25)
        f1.render_to(screen,[130,190],"确认并继续",(tcd1),size=20)
        pygame.display.update()

        def dysz():
            global t
            if t<=0 or t>=10000000000000:
                pygame.draw.rect(screen, (white), [100,130,400,50], 0)
                f1.render_to(screen,[130,170],"——————",(red),size=25)
                t=t//10
            else:
                pygame.draw.rect(screen, (white), [100,130,400,50], 0)
                f1.render_to(screen,[130,170],"——————",(black),size=25)
            f1.render_to(screen,[130,150],str(t),(tcd1),size=20)
            pygame.display.update() 
        
        count=2
        while count>1:
            for event in pygame.event.get():
                if event.type == QUIT:
                    exit()
                if event.type == KEYDOWN:
                    ifinput()
                if event.type == pygame.MOUSEBUTTONUP:
                    mx,my=pygame.mouse.get_pos()
                    if 130<mx<230 and 190<my<210:
                        count-=1
                    
            
        a=t
        screen.fill((white))
        f1.render_to(screen,[50,30],"结果：",(gray),size=17)
        f1.render_to(screen,[400,90],"算数平方根",(gray),size=17)
        f1.render_to(screen,[250,90],"质因数分解",(gray),size=17)
        f1.render_to(screen,[100,90],"输入的数字",(gray),size=17)
        pygame.display.update()
        f1.render_to(screen,[100,120],str(t),(tcd1),size=15)
        pygame.display.update()

        pygame.display.update()
        pz=120
        while x<=a:
            while math.ceil(a/x)==a/x:
                a=a/x
                y=y+1
            if y>0:
                f1.render_to(screen,[250,pz],str(x),(tcd1),size=15)
                f1.render_to(screen,[310,pz],"^",(tcd1),size=15)
                f1.render_to(screen,[325,pz],str(y),(tcd1),size=15)
                pygame.display.update()
                pz+=20
                
                pygame.draw.rect(screen,(tcd1),[math.ceil((600-600//t)/t*x),0,600//t,20],0)
                pygame.display.update()

            if y//2==y/2:
                z=z*x**(y//2)
            else:
                xz=x*xz
                z=z*x**(y//2)
            y=0
            x=x+1
            
        pygame.display.update()
        z=z//1;xz=xz//1
        if z**2==t:
            
            pygame.draw.rect(screen,(tcl1),[math.ceil((600-600//t)/t*z)-300//t,10,600//t,10],0)
            f1.render_to(screen,[400,120],str(z),(tcd1),size=15)
            pygame.display.update()
        else:
            f1.render_to(screen,[400,120],str(z),(tcd1),size=15)
            f1.render_to(screen,[425,120],"倍根号",(tcd1),size=15)
            f1.render_to(screen,[470,120],str(xz),(tcd1),size=15)
            pygame.display.update()
 

    if mode==2:
        screen.fill((white))
        bgrc(tcl2)
        raref(50,30,tcl2,500,250,20,5)
        f1.render_to(screen,[500,280],"Watth",(tcd2),size=20)
        
        f1.render_to(screen,[130,65],"输入坐标",(black),size=25)
        f1.render_to(screen,[130,100],"我们会为你计算三角形面积",(black),size=15)
        
        pygame.display.update()
             
        
        t=fh=0
        x1=x2=x3=y1=y2=y3=0
        def dysz():
            global x1,x2,x3,y1,y2,y3,t,a,fh
            if fh==1:
                t=-abs(t)
            if a==1:
                x1=t
            if a==2:
                y1=t
            if a==3:
                x2=t
            if a==4:
                y2=t
            if a==5:
                x3=t
            if a==6:
                y3=t
            pygame.draw.rect(screen, (white), [130,120,200,100], 0)
            f1.render_to(screen,[130,130],"A    (             ,             )",(black),size=20)
            f1.render_to(screen,[130,160],"B    (             ,             )",(black),size=20)
            f1.render_to(screen,[130,190],"C    (             ,             )",(black),size=20)
            f1.render_to(screen,[180,147],"———",(tcd2),size=20)
            f1.render_to(screen,[265,147],"———",(tcd2),size=20)
            f1.render_to(screen,[180,177],"———",(tcd2),size=20)
            f1.render_to(screen,[265,177],"———",(tcd2),size=20)
            f1.render_to(screen,[180,207],"———",(tcd2),size=20)
            f1.render_to(screen,[265,207],"———",(tcd2),size=20)
            if a==1:
                if x1<=-10000 or x1>=10000:
                    f1.render_to(screen,[180,147],"———",(red),size=20)
                    t=t//10
                    x1=x1//10
                else:
                    f1.render_to(screen,[180,147],"———",(tcl2),size=20)
            if a==2:
                if y1<=-10000 or y1>=10000:
                    f1.render_to(screen,[265,147],"———",(red),size=20)
                    t=t//10
                    y1=y1//10
                else:
                    f1.render_to(screen,[265,147],"———",(tcl2),size=20)
            if a==3:
                if x2<=-10000 or x2>=10000:
                    f1.render_to(screen,[180,177],"———",(red),size=20)
                    t=t//10
                    x2=x2//10
                else:
                    f1.render_to(screen,[180,177],"———",(tcl2),size=20)
            if a==4:
                if y2<=-10000 or y2>=10000:
                    f1.render_to(screen,[265,177],"———",(red),size=20)
                    t=t//10
                    y2=y2//10
                else:
                    f1.render_to(screen,[265,177],"———",(tcl2),size=20)
            if a==5:
                if x3<=-10000 or x3>=10000:
                    f1.render_to(screen,[180,207],"———",(red),size=20)
                    t=t//10
                    x3=x3//10
                else:
                    f1.render_to(screen,[180,207],"———",(tcl2),size=20)
            if a==6:
                if y3<=-10000 or y3>=10000:
                    f1.render_to(screen,[265,207],"———",(red),size=20)
                    t=t//10
                    y3=y3//10
                else:
                    f1.render_to(screen,[265,207],"———",(tcl2),size=20)
            f1.render_to(screen,[180,127],str(x1),(tcd2),size=20)
            f1.render_to(screen,[265,127],str(y1),(tcd2),size=20)
            f1.render_to(screen,[180,157],str(x2),(tcd2),size=20)
            f1.render_to(screen,[265,157],str(y2),(tcd2),size=20)
            f1.render_to(screen,[180,187],str(x3),(tcd2),size=20)
            f1.render_to(screen,[265,187],str(y3),(tcd2),size=20)
            t=abs(t)
            ss=abs((x1*y2+y1*x3+x2*y3-x1*y3-y1*x2-y2*x3)/2)
            pygame.draw.rect(screen, (white), [130,230,300,20], 0)
            f1.render_to(screen,[130,230],"三角形ABC的面积为：",(wat),size=15)
            f1.render_to(screen,[280,230],str(ss),(tcd2),size=18)
            pygame.display.update() 
        count=3
        a=1
        dysz()
        dcbtn(400,140,100,tcl2,"下一个",tcd2,20)
        dcbtn(400,190,100,tcl2,"返回",tcd2,30)
        while count>1:
            
            t=0
            fh=0
            while count>2:
            
                for event in pygame.event.get():
                    if event.type == QUIT:
                        exit()
                    if event.type == KEYDOWN:
                        ifinput()
                        if event.key==pygame.K_MINUS:
                            if fh==0:
                                fh=1
                                t=-t
                            else:
                                fh=0
                            dysz()
                    if event.type == pygame.MOUSEBUTTONUP:
                        mx,my=pygame.mouse.get_pos()
                        if 387<mx<513 and 127<my<153:
                            count-=1
                        if 387<mx<513 and 177<my<203:
                            count-=9
                            mode=0
            count+=1
            a+=1
            if a==7:
                a=1
            t=0
            dysz()
        
        
        pygame.display.update()

    if mode==3:
        screen.fill((white))
        bgrc(tcl2)
        raref(50,30,tcl2,500,250,20,5)
        f1.render_to(screen,[500,280],"Watth",(tcd2),size=20)
        
        f1.render_to(screen,[130,65],"输入坐标",(black),size=25)
        f1.render_to(screen,[130,100],"我们会为你计算解析式",(black),size=15)
        
        pygame.display.update()
             
        
        t=fh=0
        x1=x2=x3=y1=y2=y3=0
        def dysz():
            global x1,x2,y1,y2,t,a,fh
            if fh==1:
                t=-abs(t)
            if a==1:
                x1=t
            if a==2:
                y1=t
            if a==3:
                x2=t
            if a==4:
                y2=t
            
            pygame.draw.rect(screen, (white), [130,120,200,100], 0)
            f1.render_to(screen,[130,130],"A    (             ,             )",(black),size=20)
            f1.render_to(screen,[130,160],"B    (             ,             )",(black),size=20)
            f1.render_to(screen,[180,147],"———",(tcd2),size=20)
            f1.render_to(screen,[265,147],"———",(tcd2),size=20)
            f1.render_to(screen,[180,177],"———",(tcd2),size=20)
            f1.render_to(screen,[265,177],"———",(tcd2),size=20)
            if a==1:
                if x1<=-10000 or x1>=10000:
                    f1.render_to(screen,[180,147],"———",(red),size=20)
                    t=t//10
                    x1=x1//10
                else:
                    f1.render_to(screen,[180,147],"———",(tcl2),size=20)
            if a==2:
                if y1<=-10000 or y1>=10000:
                    f1.render_to(screen,[265,147],"———",(red),size=20)
                    t=t//10
                    y1=y1//10
                else:
                    f1.render_to(screen,[265,147],"———",(tcl2),size=20)
            if a==3:
                if x2<=-10000 or x2>=10000:
                    f1.render_to(screen,[180,177],"———",(red),size=20)
                    t=t//10
                    x2=x2//10
                else:
                    f1.render_to(screen,[180,177],"———",(tcl2),size=20)
            if a==4:
                if y2<=-10000 or y2>=10000:
                    f1.render_to(screen,[265,177],"———",(red),size=20)
                    t=t//10
                    y2=y2//10
                else:
                    f1.render_to(screen,[265,177],"———",(tcl2),size=20)
            
            f1.render_to(screen,[180,127],str(x1),(tcd2),size=20)
            f1.render_to(screen,[265,127],str(y1),(tcd2),size=20)
            f1.render_to(screen,[180,157],str(x2),(tcd2),size=20)
            f1.render_to(screen,[265,157],str(y2),(tcd2),size=20)
            
            t=abs(t)
            ychs=0
            if x2-x1!=0:
                k=(y2-y1)/(x2-x1)
                b=y1-k*x1
            else:
                ychs=1
            
            if ychs==0:
                if b>=0:
                    f1.render_to(screen,[130,190],"y=              x+",(tcd3),size=20)
                else:
                    f1.render_to(screen,[130,190],"y=              x-",(tcd3),size=20)
                    b=abs(b)
                if k*1000!=(k*1000)//1 or b*1000!=(b*1000)//1:
                    k=(k*1000)//1/1000
                    b=(b*1000)//1/1000
                    f1.render_to(screen,[130,220],"已从千分位后截断",(wat),size=10)
                f1.render_to(screen,[160,190],str(k),(tcd3),size=20)
                f1.render_to(screen,[265,190],str(b),(tcd3),size=20)
                pygame.display.update()
            else:
                f1.render_to(screen,[130,190],"x=",(tcd3),size=20)
                f1.render_to(screen,[160,190],str(x1),(tcd3),size=20)
                pygame.display.update() 
        count=3
        a=1
        dysz()
        dcbtn(400,140,100,tcl2,"下一个",tcd2,20)
        dcbtn(400,190,100,tcl2,"返回",tcd2,30)
        while count>1:
            
            t=0
            fh=0
            while count>2:
            
                for event in pygame.event.get():
                    if event.type == QUIT:
                        exit()
                    if event.type == KEYDOWN:
                        ifinput()
                        if event.key==pygame.K_MINUS:
                            if fh==0:
                                fh=1
                                t=-t
                            else:
                                fh=0
                            dysz()
                    if event.type == pygame.MOUSEBUTTONUP:
                        mx,my=pygame.mouse.get_pos()
                        if 387<mx<513 and 127<my<153:
                            count-=1
                        if 387<mx<513 and 177<my<203:
                            count-=9
                            mode=0
            count+=1
            a+=1
            if a==5:
                a=1
            t=0
            dysz()
        
        
        pygame.display.update()


    dcbtn(220,260,60,lgray,"返回",black,5)

    if count>0:
        if mode==0:
            dcbtn(320,260,60,lgray,"继续",lgray,5)
        else:
            dcbtn(320,260,60,lgray,"继续",black,5)
    
    while count>0:
        for event in pygame.event.get():
            if event.type == QUIT:
                exit()
            if event.type == KEYDOWN:
                if event.key==pygame.K_q:
                    count-=1
                if event.key==pygame.K_w:
                    count-=1
                if event.key==pygame.K_e:
                    count-=1
            if event.type == pygame.MOUSEBUTTONUP:
                mx,my=pygame.mouse.get_pos()
                if 208<mx<292 and 245<my<275:
                    mode=0
                    count-=1
                if 308<mx<392 and 245<my<275:
                    if mode>0:
                        count-=1

                                