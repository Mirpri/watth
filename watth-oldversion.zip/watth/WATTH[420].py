import pygame
import pygame.freetype
import sys
def bcolor():
    global white
    global gray
    global lgray
    global llgray
    global lred
    global wat
    global lwat
    global black
    global tcd1
    global tcl1
    global tcd2
    global tcl2
    global tcd3
    global tcl3
    white=255,255,255
    gray=140,140,140
    lgray=240,240,240
    llgray=245,245,245
    lred=255,230,230
    wat=0,90,100
    lwat=190,232,237
    black=0,0,0
    tcd1=wat
    tcl1=lwat
    tcd2=wat
    tcl2=lwat
    tcd3=wat
    tcl3=lwat
bcolor()


pygame.init()
screencaption=pygame.display.set_caption("Watth420")
screen=pygame.display.set_mode([600,320])
screen.fill((white))
def rare(x,y,color,lenth,width,r):
    pygame.draw.circle(screen,(color),[x+r,y+r],r,0)
    pygame.draw.circle(screen,(color),[x+lenth-r,y+width-r],r,0)
    pygame.draw.circle(screen,(color),[x+lenth-r,y+r],r,0)
    pygame.draw.circle(screen,(color),[x+r,y+width-r],r,0)
    pygame.draw.rect(screen, (color), [x+r,y,lenth-(2*r),width], 0)
    pygame.draw.rect(screen, (color), [x,y+r,lenth,width-(2*r)], 0)
rare(50,50,lwat,500,220,20)
rare(53,53,white,494,214,20)
f1=pygame.freetype.Font(r"C:\Windows\Fonts\msyh.ttc",36)
f1.render_to(screen,[160,110],"Watth",(wat),size=90)
f1.render_to(screen,[165,115],"Watth",(190,232,237,180),size=90)
pygame.display.update()
import random
import math
from pygame.locals import *
import time
time.sleep(1)
m=0
t=0
mode=0
def dcbtn(sx,sy,lenth,color,width):
    l1=lenth//4
    x1=sx
    x2=sx
    while l1:
        pygame.draw.circle(screen,(color),[x1,sy],width,0)
        
        pygame.display.update()
        time.sleep(0.005)
        x1+=4
        l1-=1
    
def ifinput():
    global t
    global count
    if event.key==pygame.K_RETURN:
        count-=1
    if event.key==pygame.K_BACKSPACE:
        t=t//10 
        dysz()
    if event.key == pygame.K_1:
        t=10*t+1
        dysz()
    if event.key == pygame.K_2:
        t=10*t+2
        dysz()
    if event.key == pygame.K_3:
        t=10*t+3
        dysz()
    if event.key == pygame.K_4:
        t=10*t+4
        dysz()
    if event.key == pygame.K_5:
        t=10*t+5
        dysz()
    if event.key == pygame.K_6:
        t=10*t+6
        dysz()
    if event.key == pygame.K_7:
        t=10*t+7
        dysz()
    if event.key == pygame.K_8:
        t=10*t+8
        dysz()
    if event.key == pygame.K_9:
        t=10*t+9
        dysz()
    if event.key == pygame.K_0:
        t=10*t+0
        dysz()
def iptbox(color,lenth):
    xc=180
    count=lenth//2
    while count:
        pygame.draw.circle(screen,(lgray),[xc,37],15,0)
        pygame.display.update()
        time.sleep(0.003)
        xc+=2
        count-=1
    count=35
    while count:
        pygame.draw.circle(screen,(color),[xc,37],15,0)
        
        pygame.display.update()
        time.sleep(0.003)
        xc+=2
        count-=1
    pygame.draw.rect(screen, (lgray), [180,22,lenth,30], 0)
    f1.render_to(screen,[200+lenth,33],"确认",(black),size=15)
    pygame.display.update()
def home():
    screen.fill((white))
    f1.render_to(screen,[80,70],"欢迎使用",(wat),size=30)
    f1.render_to(screen,[80,120],"Watth",(wat),size=40)
    rare(0,280,lgray,600,40,5)
    rare(3,283,white,594,34,5)
    f1.render_to(screen,[550,290],"退出",(wat),size=18)
    f1.render_to(screen,[490,290],"关于",(wat),size=18)
    f1.render_to(screen,[430,290],"选项",(wat),size=18)


    x=290
    count=110
    while count:
        pygame.draw.circle(screen,(tcl1),[x,80],15,0)
        pygame.draw.circle(screen,(tcl2),[x,140],15,0)
        pygame.draw.circle(screen,(tcl3),[x,200],15,0)
        pygame.display.update()
        time.sleep(0.002)
        x+=2
        count-=1
    x=290
    count=110
    while count:
        pygame.draw.circle(screen,(white),[x,80],12,0)
        pygame.draw.circle(screen,(white),[x,140],12,0)
        pygame.draw.circle(screen,(white),[x,200],12,0)
        pygame.display.update()
        time.sleep(0.002)
        x+=2
        count-=1

    f1.render_to(screen,[300,70],"质因数分解及开方（Q）",(black),size=17)
    f1.render_to(screen,[300,130],"计算三角形面积（W）",(black),size=17)
    f1.render_to(screen,[300,190],"求直线解析式（E）",(black),size=17)
    mode=0
    pygame.display.update()

#主循环
while True:
    screen.fill((white))
    if mode==0:
        home()
        count=1
        while count:
            for event in pygame.event.get():
                if event.type == QUIT:
                    exit()
                if event.type == KEYDOWN:
                    if event.key==pygame.K_q:
                        mode=1
                        count-=1
                    if event.key==pygame.K_w:
                        mode=2
                        count-=1
                    if event.key==pygame.K_e:
                        mode=3
                        count-=1
                    if event.key==pygame.K_ESCAPE:
                        sys.exit()
                if event.type == pygame.MOUSEBUTTONUP:
                    mx,my=pygame.mouse.get_pos()
                    if 290<mx<510 and 65<my<95:
                        mode=1
                        count-=1
                    if 290<mx<510 and 125<my<155:
                        mode=2
                        count-=1 
                    if 290<mx<510 and 185<my<215:
                        mode=3
                        count-=1 
                    if 540<mx<600 and 280<my<320:
                        sys.exit()
                    if 480<mx<535 and 280<my<320:
                        mode=0
                        count-=1
                    if 420<mx<475 and 280<my<320:
                        mode=0.1
                        count-=1
    
    if mode==0.1:
        screen.fill((white))
        f1.render_to(screen,[50,40],"选择主题",(wat),size=20)
        dcbtn(200,50,50,lgray,15)
        dcbtn(300,50,50,lgray,15)
        dcbtn(400,50,50,lgray,15)
        f1.render_to(screen,[210,42],"彩色",(gray),size=15)
        f1.render_to(screen,[310,42],"黑暗",(gray),size=15)
        f1.render_to(screen,[410,42],"默认",(gray),size=15)
        pygame.display.update()
        count=1
        while count:
            for event in pygame.event.get():
                if event.type == QUIT:
                    exit()
                if event.type == pygame.MOUSEBUTTONUP:
                    mx,my=pygame.mouse.get_pos()
                    if 200<mx<250 and 35<my<65:
                        bcolor()
                        tcd1=100,140,140
                        tcl1=190,220,220
                        tcd2=100,100,140
                        tcl2=190,190,220
                        tcd3=140,100,140
                        tcl3=220,190,220
                        count-=1
                    if 300<mx<350 and 35<my<65:
                        bcolor()
                        tcd1=lwat
                        tcl1=wat
                        tcd2=lwat
                        tcl2=wat
                        tcd3=lwat
                        tcl3=wat
                        lgray=100,100,100
                        lred=150,50,50
                        gray=240,240,240
                        wat=lwat
                        black=white
                        white=0,0,0
                        count-=1
                    if 400<mx<450 and 35<my<65:
                        bcolor()
                        count-=1
    if mode==0:
        screen.fill((white))
        f1.render_to(screen,[100,50],"WATTH",(wat),size=20)
        f1.render_to(screen,[100,100],"版本:    420(Simplified Chinese)",(wat),size=17)
        f1.render_to(screen,[100,150],"发布日期:    2020.7.14",(wat),size=17)
    if mode==1:  
        screen.fill((white))
        f1.render_to(screen,[500,280],"Watth",(tcl1),size=20)
        t=0
        
        x=2
        y=0
        z=1
        xz=1
        m=2
        n=0
        p=0
        q=0
        xc=180
        count=65
        iptbox(tcl1,130)
        f1.render_to(screen,[400,90],"算数平方根",(gray),size=17)
        f1.render_to(screen,[250,90],"质因数分解",(gray),size=17)
        f1.render_to(screen,[100,90],"输入的数字",(gray),size=17)
        f1.render_to(screen,[60,28],"输入数字",(black),size=20)
        pygame.display.update()

        def dysz():
            global t
            if t<=0 or t>=10000000:
                pygame.draw.rect(screen, (lred), [180,25,127,25], 0)
                pygame.draw.circle(screen,(lred),[180,37],12,0)
                t=t//10
            else:
                pygame.draw.rect(screen, (lgray), [180,25,130,25], 0)
                pygame.draw.circle(screen,(lgray),[180,37],12,0)
            f1.render_to(screen,[200,30],str(t),(tcd1),size=20)
            pygame.display.update() 
        
        count=1
        while count:
            for event in pygame.event.get():
                if event.type == QUIT:
                    exit()
                if event.type == KEYDOWN:
                    ifinput()
                if event.type == pygame.MOUSEBUTTONUP:
                    mx,my=pygame.mouse.get_pos()
                    if 310<mx<380 and 25<my<50:
                        count-=1
                    
            
        a=t
        
        pygame.draw.rect(screen, (white), [50,20,600,50], 0)
        f1.render_to(screen,[50,30],"结果：",(gray),size=17)
        pygame.display.update()
        f1.render_to(screen,[100,120],str(t),(tcd1),size=15)
        pygame.display.update()

        pygame.display.update()
        pz=120
        while x<=a:
            while math.ceil(a/x)==a/x:
                a=a/x
                y=y+1
            if y>0:
                f1.render_to(screen,[250,pz],str(x),(tcd1),size=15)
                f1.render_to(screen,[310,pz],"^",(tcd1),size=15)
                f1.render_to(screen,[325,pz],str(y),(tcd1),size=15)
                pygame.display.update()
                pz+=20
                
                pygame.draw.rect(screen,(tcd1),[math.ceil((600-600//t)/t*x),0,600//t,20],0)
                pygame.display.update()

            if y//2==y/2:
                z=z*x**(y//2)
            else:
                xz=x*xz
                z=z*x**(y//2)
            y=0
            x=x+1
            
        pygame.display.update()
        z=z//1;xz=xz//1
        if z**2==t:
            
            pygame.draw.rect(screen,(tcl1),[math.ceil((600-600//t)/t*z)-300//t,10,600//t,10],0)
            f1.render_to(screen,[400,120],str(z),(tcd1),size=15)
            pygame.display.update()
        else:
            f1.render_to(screen,[400,120],str(z),(tcd1),size=15)
            f1.render_to(screen,[425,120],"倍根号",(tcd1),size=15)
            f1.render_to(screen,[470,120],str(xz),(tcd1),size=15)
            pygame.display.update()
 

    if mode==2:
        screen.fill((255,255,255))
        f1.render_to(screen,[500,280],"Watth",(tcl2),size=20)
        f1.render_to(screen,[110,100],"A    (             ,             )",(0,0,0),size=15)
        f1.render_to(screen,[110,140],"B    (             ,             )",(0,0,0),size=15)
        f1.render_to(screen,[110,180],"C    (             ,             )",(0,0,0),size=15)
        f1.render_to(screen,[100,30],"输入坐标",(0,0,0),size=15)
        
        f1.render_to(screen,[320,100],"三角形ABC的面积为：",(wat),size=20)
        pygame.display.update()
        iptbox(tcl2,100)
        
        
        t=0
        def dysz():
            global t
            if t<=-10000 or t>=10000:
                pygame.draw.rect(screen, (lred), [180,25,97,25], 0)
                pygame.draw.circle(screen,(lred),[180,37],12,0)
                t=t//10
            else:
                pygame.draw.rect(screen, (lgray), [180,25,100,25], 0)
                pygame.draw.circle(screen,(lgray),[180,37],12,0)
            if fh==1:
                t=-abs(t)
            f1.render_to(screen,[200,30],str(t),(tcd2),size=20)
            t=abs(t)
            pygame.display.update() 
        count=1
        a=1
       
        while a<7:
            count=1
            t=0
            fh=0
            while count:
            
                for event in pygame.event.get():
                    if event.type == QUIT:
                        exit()
                    if event.type == KEYDOWN:
                        ifinput()
                        if event.key==pygame.K_MINUS:
                            if fh==0:
                                fh=1
                                t=-t
                            else:
                                fh=0
                            dysz()
                    if event.type == pygame.MOUSEBUTTONUP:
                        mx,my=pygame.mouse.get_pos()
                        if 280<mx<350 and 25<my<50:
                            count-=1
                        
            if fh==1:
                t=-t
            if -10000<t<10000:
                if a==1:
                    x1=t
                    f1.render_to(screen,[150,100],str(x1),(tcd2),size=15)
                    pygame.display.update()
                if a==2:
                    y1=t
                    f1.render_to(screen,[200,100],str(y1),(tcd2),size=15)
                    pygame.display.update()
                if a==3:
                    x2=t
                    f1.render_to(screen,[150,140],str(x2),(tcd2),size=15)
                    pygame.display.update()
                if a==4:
                    y2=t
                    f1.render_to(screen,[200,140],str(y2),(tcd2),size=15)
                    pygame.display.update()
                if a==5:
                    x3=t
                    f1.render_to(screen,[150,180],str(x3),(tcd2),size=15)
                    pygame.display.update()
                if a==6:
                    y3=t
                    f1.render_to(screen,[200,180],str(y3),(tcd2),size=15)
                    pygame.display.update()
                pygame.draw.rect(screen, (lgray), [180,25,100,25], 0)
            else:
                a-=1    
                pygame.draw.rect(screen,(lred), [180,25,100,25], 0)
            pygame.display.update()
            a+=1
        ss=abs((x1*y2+y1*x3+x2*y3-x1*y3-y1*x2-y2*x3)/2)
        pygame.draw.rect(screen,(white), [50,20,400,50], 0)
        f1.render_to(screen,[50,30],"结果：",(gray),size=20)
        print(ss)
        f1.render_to(screen,[340,150],str(ss),(tcd2),size=40)
        
        pygame.display.update()

    if mode==3:
        screen.fill((white))
        f1.render_to(screen,[500,280],"Watth",(tcl3),size=20)
        f1.render_to(screen,[110,100],"A    (             ,             )",(black),size=15)
        f1.render_to(screen,[110,140],"B    (             ,             )",(black),size=15)
        f1.render_to(screen,[100,30],"输入坐标",(black),size=15)
        f1.render_to(screen,[310,100],"直线AB的解析式为",(gray),size=18)
        pygame.display.update()
        
        iptbox(tcl3,100)
        t=0
        def dysz():
            global t
            if t<=-10000 or t>=10000:
                pygame.draw.rect(screen, (lred), [180,25,97,25], 0)
                pygame.draw.circle(screen,(lred),[180,37],12,0)
                t=t//10
            else:
                pygame.draw.rect(screen, (lgray), [180,25,100,25], 0)
                pygame.draw.circle(screen,(lgray),[180,37],12,0)
            if fh==1:
                t=-abs(t)
            f1.render_to(screen,[200,30],str(t),(tcd3),size=20)
            t=abs(t)
            pygame.display.update() 
        count=1
        a=1
       
        while a<5:
            count=1
            t=0
            fh=0
            while count:
            
                for event in pygame.event.get():
                    if event.type == QUIT:
                        exit()
                    if event.type == KEYDOWN:
                        
                        if event.key==pygame.K_MINUS:
                            if fh==0:
                                fh=1
                                t=-t
                            else:
                                fh=0
                            dysz()
                        ifinput()
                    if event.type == pygame.MOUSEBUTTONUP:
                        mx,my=pygame.mouse.get_pos()
                        if 280<mx<350 and 25<my<50:
                            count-=1
            if fh==1:
                t=-t
            if -10000<t<10000:
                if a==1:
                    x1=t
                    f1.render_to(screen,[150,100],str(x1),(tcd3),size=15)
                    pygame.display.update()
                if a==2:
                    y1=t
                    f1.render_to(screen,[200,100],str(y1),(tcd3),size=15)
                    pygame.display.update()
                if a==3:
                    x2=t
                    f1.render_to(screen,[150,140],str(x2),(tcd3),size=15)
                    pygame.display.update()
                if a==4:
                    y2=t
                    f1.render_to(screen,[200,140],str(y2),(tcd3),size=15)
                    pygame.display.update()
                    
                        
                pygame.draw.rect(screen, (lgray), [180,25,100,25], 0)
                
            else:
                a-=1    
                pygame.draw.rect(screen, (lred), [180,25,100,25], 0)
            pygame.display.update()
            a+=1
        ychs=0
        pygame.draw.rect(screen, (white), [50,20,400,50], 0)
        f1.render_to(screen,[50,30],"结果：",(155,155,155),size=20)
        if x2-x1!=0:
            k=(y2-y1)/(x2-x1)
            b=y1-k*x1
        else:
            ychs=1
        
        
        if ychs==0:
            if b>=0:
                f1.render_to(screen,[310,140],"y=              x+",(tcd3),size=20)
            else:
                f1.render_to(screen,[310,140],"y=              x-",(tcd3),size=20)
                b=abs(b)
            if k*1000!=(k*1000)//1 or b*1000!=(b*1000)//1:
                k=(k*1000)//1/1000
                b=(b*1000)//1/1000
                f1.render_to(screen,[310,180],"已从千分位后截断",(wat),size=10)
            f1.render_to(screen,[340,140],str(k),(tcd3),size=20)
            f1.render_to(screen,[440,140],str(b),(tcd3),size=20)
            pygame.display.update()
        else:
            f1.render_to(screen,[310,140],"x=",(tcd3),size=20)
            f1.render_to(screen,[340,140],str(x1),(tcd3),size=20)

    dcbtn(220,260,60,lgray,12)
    dcbtn(320,260,60,lgray,12)
    
    f1.render_to(screen,[230,254],"返回",(black),size=15)
    if mode==0:
        f1.render_to(screen,[330,254],"继续",(gray),size=15)
    else:
        f1.render_to(screen,[330,254],"继续",(black),size=15)
    pygame.display.update()
    count=1
    while count:
        for event in pygame.event.get():
            if event.type == QUIT:
                exit()
            if event.type == KEYDOWN:
                if event.key==pygame.K_q:
                    count-=1
                if event.key==pygame.K_w:
                    count-=1
                if event.key==pygame.K_e:
                    count-=1
            if event.type == pygame.MOUSEBUTTONUP:
                mx,my=pygame.mouse.get_pos()
                if 208<mx<292 and 245<my<275:
                    mode=0
                    count-=1
                if 308<mx<392 and 245<my<275:
                    if mode>0:
                        count-=1

                                