import tkinter
from tkinter import *
from tkinter import messagebox
import math
import time
import json

tow=0

root=tkinter.Tk()
root.title("Watth")
root.iconbitmap("ims\\w10.ico")
#root["background"] = "white"
root.resizable(0,0)
root.geometry("520x390")
def empl(row,column):
    l1=Label(root,text='  ')
    l1.grid(row=row,column=column)
def ftopi(on):
    if on==1:
        ftop=Frame(root,width=520,height=2,bg=c_hili)
    else:
        ftop=Frame(root,width=520,height=2,bg="white")
    ftop.grid(row=1,column=10,columnspan=100)

ftopi(0)
empl(row=2,column=10)
watl = tkinter.PhotoImage(file="ims\\w12.png")
llogo=Label(root,image=watl)
llogo.grid(row=5,column=10)
#读取设置
filename='set.json'
with open(filename) as file_obj:
    set=json.load(file_obj)
    icl=set%10
    rnw=(set//10)%10
    lcy=(set//100)%10
c_hili='green'
#读取语言
with open("lan.txt", "r",encoding='utf-8') as f:  # 打开文件
    tx_关于= f.readline().splitlines()  # 读取文件
    tx_设置= f.readline().splitlines()
    tx_set_显示日志= f.readline().splitlines()
    tx_set_在新窗口显示= f.readline().splitlines()
    tx_set_直接列出质因数= f.readline().splitlines()
    tx_确定= f.readline().splitlines()
    tx_获取= f.readline().splitlines()
    tx_分解质因数= f.readline().splitlines()
    tx_所有因数= f.readline().splitlines()
    tx_算术平方根= f.readline().splitlines()
    tx_警告= f.readline().splitlines()
    tx_请输入数字= f.readline().splitlines()
    tx_请输入大于1的整数= f.readline().splitlines()
    tx_中止= f.readline().splitlines()
    tx_结果= f.readline().splitlines()
    tx_还未分解的因数= f.readline().splitlines()
    tx_已中止= f.readline().splitlines()
    tx_已完成= f.readline().splitlines()
    tx_结果将在此显示= f.readline().splitlines()
    tx_功能选项= f.readline().splitlines()
    tx_正在进行运算= f.readline().splitlines()
    tx_确实要退出吗= f.readline().splitlines()


if rnw==1:
    root.geometry("285x385")
filename='key.json'
with open(filename) as file_obj:
    key=json.load(file_obj)
if key!=0:
    tx_关于='Register!'
'''
l1=Label(root,text='欢迎',wraplength=0,width=24,font=("等线",15))
l1.grid(row=9,column=10)


root.update()
time.sleep(0.5)
'''

#主界面
setwinison=0
abwinison=0



def abt():
    global abwinison
    if abwinison==0:
        global abwin,atex
        abwinison=1
        abwin=tkinter.Tk()
        abwin.title(tx_关于)
        abwin.iconbitmap("ims\\w10.ico")
        #abwin["background"] = "white"
        abwin.resizable(0,0)
        abwin.geometry("200x300")
        Label(abwin,text='').pack()
        atex=Text(abwin,width=25,height=8,fg='black',bd=0,font=("等线",10))
        atex.pack()
        atex.insert(INSERT,"version:\nwatth (GUI) 14.3\n\n")
        #e1=Entry(abwin,bd=0,font=("等线",12),justify='center',bg='whitesmoke')
        #e1.pack()
        filename='key.json'
        with open(filename) as file_obj:
            key=json.load(file_obj)
        if key!=0:
            atex.insert(INSERT,"KEY HERE:")
        else:
            atex.insert(INSERT,"REGISTERED")

        def a_on_closing():
            global abwinison,atex,tow
            
            filename='key.json'
            with open(filename) as file_obj:
                key=json.load(file_obj)
            if key!=0:
                
                def askforreg():
                    global tow
                    if tow<=2:
                        atex.insert(INSERT,("\nYOU MUST REGISTER",tow))
                        tow+=1
                    else:
                        abwin.destroy()
                        root.destroy()
                try:
                    name=atex.get("4.9","4.15")#密钥是六位数
                    #print(name,key)
                    if int(key)==int(name):
                        
                        with open(filename,'w') as file_obj:
                            json.dump(0,file_obj)
                        abwinison=0
                        abwin.destroy()
                    else:
                        askforreg()
                except:
                    askforreg()
                    
            else:
                abwinison=0
                abwin.destroy()

        abwin.protocol('WM_DELETE_WINDOW', a_on_closing)
def sz():
    global setwinison
    if setwinison==0:
        global setwin ,iicl,irnw,ilcy
        setwinison=1
        setwin=tkinter.Tk()
        setwin.title(tx_设置)
        setwin.iconbitmap("ims\\w10.ico")
        #setwin["background"] = "white"
        setwin.resizable(0,0)
        setwin.geometry("200x300")
        l1=Label(setwin,text='')
        l1.pack()
        
        
        
        def aa():
            print(iicl.get())

        Label(setwin,text='').pack()
        global icl,rnw,lcy

        iicl= IntVar()
        irnw= IntVar()
        ilcy= IntVar()
        csl=Checkbutton(setwin,text=tx_set_显示日志,variable=iicl,onvalue=1,offvalue=2,command=aa)
        csl.pack()
        Label(setwin,text='').pack()
        crnw=Checkbutton(setwin,text=tx_set_在新窗口显示,variable=irnw,onvalue=1,offvalue=0)
        crnw.pack()
        
        Label(setwin,text='').pack()
        lcys=Checkbutton(setwin,text=tx_set_直接列出质因数,variable=ilcy,onvalue=1,offvalue=0)
        lcys.pack()
        if icl==1:
            csl.select()
        if rnw==1:
            crnw.select()
        if lcy==1:
            lcys.select()
        print(iicl.get())
        def s_on_closing():
            global setwinison,iicl,irnw,ilcy,icl,rnw,lcy
            setwinison=0
            print(iicl.get())
            icl=iicl.get()
            rnw=irnw.get()
            if rnw==0:#调整窗口大小
                rnw=1
                root.geometry("285x385")
            elif rnw==1:
                rnw=0
                root.geometry("510x385")
            lcy=ilcy.get()

            set=icl+10*rnw+100*lcy
            with open('set.json','w') as file_obj:
                json.dump(set,file_obj)
        
            setwin.destroy()


        setwin.protocol('WM_DELETE_WINDOW', s_on_closing)
def stop():
    global stp
    stp=1
def comm(event):
    com()
ifu1=1
ifu2=0
def wfct():
    #40,10 
    def clowftc():
        global vfu1,ifu1,vfu2,ifu2
        #print (vfu1.get())
        ifu1=vfu1.get()
        ifu2=vfu2.get()
        bw.destroy()
        fu1.destroy()
        fu2.destroy()
        fi.destroy()
        li.destroy()
    
    fi=Frame(root,width=180,height=140)
    fi.grid(row=30,column=10,rowspan=11)
    bw=Button(root,fg=c_hili,text=tx_确定,width=20,command=clowftc,bd=0)
    bw.grid(row=40,column=10)
    global vfu1,ifu1,vfu2,ifu2
    li=Label(root,text=("*  ",tx_分解质因数),width=20)
    li.grid(row=30,column=10)
    vfu1=IntVar()
    vfu2=IntVar()
    fu1=Checkbutton(root,text=tx_算术平方根,onvalue=1,variable=vfu1)
    fu1.grid(row=33,column=10)
    fu2=Checkbutton(root,text=tx_所有因数,onvalue=1,variable=vfu2)
    fu2.grid(row=36,column=10)
    if ifu1==1:
        fu1.select()
    if ifu2==1:
        fu2.select()

doing=0
def com():
    try:
        global bt,doing,icl,ifu1
        global stp
        t="a"
        t=float(e1.get())
        t=int(t)
        if t<2 or t==float(e1.get()):
            doing=1
    except:
        try:
            if t<=0:
                messagebox.showwarning(tx_警告,tx_请输入大于1的整数)
        except:
            messagebox.showwarning(tx_警告,tx_请输入数字)
    
    if doing==1:  
        global watla0,watla1
        ftopi(1)
        watla0 = tkinter.PhotoImage(file="ims\\w12-a0.png")
        watla1 = tkinter.PhotoImage(file="ims\\w12-a1.png")
        la0=Label(root,image=watla0)
        la0.grid(row=5,column=10)
        root.update()
        time.sleep(0.03)
        la1=Label(root,image=watla1)
        la1.grid(row=5,column=10)

        bst=Button(root,text=tx_中止,command=stop,relief=GROOVE,width=20,activebackground="pink")
        bst.grid(row=30,column=10)
        #l1.config(text=t)
        #text.destroy()
        global text
        if rnw==1:
            resu=tkinter.Tk()
            resu.title(tx_结果)
            resu.iconbitmap("ims\\w10.ico")
            #resu["background"] = "white"
            resu.resizable(0,100)
            resu.geometry("200x300")
            l1=Label(resu,text=t,width=20,font=("等线",10,"bold"))
            l1.pack()
            text=Text(resu,width=25,height=100,fg='black',bd=0,font=("等线",10))
            text.pack()
        else:
            
            #text=Text(root,width=22,height=18,fg='black',bd=0,relief=GROOVE,font=("等线",10))
            #text.grid(row=5,column=20,rowspan=100)
            text.delete(1.0, END)
            text.insert(INSERT,"\n")
            text.insert(INSERT,"\n")
            l1=Label(root,text=t,width=20,bg='white',font=("等线",10,"bold"))
            l1.grid(row=5,column=20,sticky=N,pady=5)
        
        if icl==1:#初始化日志标签样式
            text.tag_add('tag_1',INSERT)
            text.tag_config('tag_1',foreground = 'green',font=("等线",9))
            text.tag_add('tag_2',INSERT)
            text.tag_config('tag_2',foreground = 'black')

        a=t
        x=2
        y=0
        z=1
        xz=1
        tried=0
        m=2
        n=0
        p=0
        q=0
        stp=0
        total=math.sqrt(a)
        freq=int(total/20000)+1
        #print(freq)
        #print(ii)
        
        #l1=Label(root,text=("最大运算量",int((total-x)/2)),width=20)
        #l1=Label(root,text=(int(x/math.sqrt(a)*100),"％"))
        #l1.grid(row=20,column=10)
        root.update()
        text.insert(INSERT,tx_分解质因数)
        text.insert(INSERT,"\n")
        while x<=a and stp==0:
            
            tried+=1
            
            if x**2>a:
                x=int(a)
            if icl==1:#显示日志
                text.insert(INSERT,("-try",x,"-"),'tag_1')
                text.insert(INSERT,"\n",'tag_2')
            while a%x==0:
                a=a/x
                total=math.sqrt(a)
                y=y+1
            if y>0:
                #print(x,'^',y,"=",x**y)
                if lcy==0:
                    text.insert(INSERT,(x,'^',y,"=",x**y))
                    text.insert(INSERT,"\n")
                else:
                    times=y
                    while times:
                        text.insert(INSERT,(x,'/'))
                        times-=1
            if y%2==0:
                z=z*x**(y//2)
            else:
                xz=x*xz
                z=z*x**(y//2)
            y=0
            if x==2:
                x-=1
            x=x+2
        if lcy==1:#直接列出因式模式下补充空行
            text.insert(INSERT,"\n")
        if icl==1:#日志运算次数
            text.insert(INSERT,("运算次数：",tried),'tag_1')
            text.insert(INSERT,("\n"),'tag_2')
        if ifu2==1:
            text.insert(INSERT,"\n")
            text.insert(INSERT,tx_所有因数)
            text.insert(INSERT,"\n")
            a=t
            x=2
            while x**2<=t and stp==0:
                
                if a%x==0:
                    text.insert(INSERT,(x,',',t//x))
                    text.insert(INSERT,"\n")
                    
                
                x=x+1
        
        #print(int((total-x)))
        root.update()
        l1x=Label(root,text=(tx_已完成),width=20)  
        if  stp==0 and ifu1==1:      
            text.insert(INSERT,"\n")
            text.insert(INSERT,tx_算术平方根)
            text.insert(INSERT,"\n")
            z=z//1;xz=xz//1
            if z**2==t:
                #print(z)
                text.insert(INSERT,z)
                text.insert(INSERT,"\n")
                
            else:
                text.insert(INSERT,(z,"*sqrt(",xz,')'))
                text.insert(INSERT,"\n")
                #print(z,xz)
        elif stp==1:
            text.insert(INSERT,tx_还未分解的因数)
            text.insert(INSERT,"\n")
            text.insert(INSERT,int(a))
            l1x=Label(root,text=(tx_已中止),width=20)
        l1x.grid(row=20,column=10)
            
        bst.destroy()
        root.update()
        time.sleep(0.3)
        la1.destroy()
        root.update()
        time.sleep(0.04)
        la0.destroy()
        ftopi(0)
        root.update()
        time.sleep(1)
        l1x.destroy()
        root.update()
    
    doing=0

t=0
stp=0
tmax=5000    
l1=Label(root,text='输入数字',wraplength=0,width=26,font=("等线",15))
l1.grid(row=9,column=10)
root.update()
e1=Entry(root,bd=0,font=("等线",16),justify='center',width=20,
            highlightthickness=2,highlightcolor=c_hili,highlightbackground='silver')
e1.grid(row=10,column=10)
empl(20,10)
bt=Button(root,background="whitesmoke",activeforeground=c_hili,text=tx_获取,command=com,relief=GROOVE,width=20)
bt.grid(row=30,column=10)
e1.bind("<Return>",comm)
text=Text(root,width=22,height=19,fg='black',bd=0,relief=GROOVE,font=("等线",13),highlightthickness=2,highlightcolor='darkgray',highlightbackground='silver')
text.insert(1.0,("--",tx_结果将在此显示))
text.grid(row=5,column=20,rowspan=100,sticky=N)
empl(9,30)

bi=Button(root,background="whitesmoke",activebackground="whitesmoke",text=tx_功能选项,fg="grey",width=20,command=wfct,relief=FLAT)
bi.grid(row=40,column=10)

empl(row=60,column=10)

#fi=Frame(root,height=70,width=294,bg="whitesmoke")
#fi.grid(row=70,column=1)

bi=Button(root,background="whitesmoke",activebackground="whitesmoke",text=tx_设置,width=9,command=sz,relief=GROOVE)
bi.grid(row=70,column=10,sticky=W,padx=74)
bi=Button(root,background="whitesmoke",activebackground="whitesmoke",text=tx_关于,width=9,command=abt,relief=GROOVE)
bi.grid(row=70,column=10,sticky=E,padx=74)
def on_closing():
    if doing==1:
        if messagebox.askokcancel(tx_正在进行运算,tx_确实要退出吗):
            root.destroy()
    else:
        root.destroy()

root.protocol("WM_DELETE_WINDOW", on_closing)
mainloop()
#pyinstaller -D Watth14.2.py -w -i C:\Users\jcliu\Documents\GitHub\Watthxx\ims\w10.ico