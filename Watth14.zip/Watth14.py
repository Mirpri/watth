import tkinter
from tkinter import *
from tkinter import messagebox
import math
import time
import json

root=tkinter.Tk()
root.title("Watth")
root.iconbitmap("w10.ico")
#root["background"] = "white"
root.resizable(0,0)
root.geometry("495x385")
def empl(row,column):
    l1=Label(root,text='  ')
    l1.grid(row=row,column=column)

empl(row=2,column=10)
l1=Label(root,text='欢迎',wraplength=0,width=24,font=("Ubuntu",15))
l1.grid(row=9,column=10)
watl = tkinter.PhotoImage(file="w12.png")
l1=Label(root,image=watl)
l1.grid(row=5,column=10)
root.update()
time.sleep(1)


#主界面
setwinison=0
abwinison=0



    
icl=0
rnw=0
def igcl():
    global icl
    if icl==0:
        icl=1
    elif icl==1:
        icl=0
    #print(icl)
def rnwi():
    global rnw
    #text.destroy()
    if rnw==0:
        rnw=1
        root.geometry("285x385")
    elif rnw==1:
        rnw=0
        root.geometry("485x385")
def abt():
    global abwinison
    if abwinison==0:
        global abwin,atex
        abwinison=1
        abwin=tkinter.Tk()
        abwin.title("关于")
        abwin.iconbitmap("w10.ico")
        #abwin["background"] = "white"
        abwin.resizable(0,0)
        abwin.geometry("200x300")
        Label(abwin,text='').pack()
        atex=Text(abwin,width=25,height=8,fg='black',bd=0,font=("Ubuntu",10))
        atex.pack()
        atex.insert(INSERT,"version:\nwatth (GUI) 14.1\n\n")
        #e1=Entry(abwin,bd=0,font=("Ubuntu",12),justify='center',bg='whitesmoke')
        #e1.pack()
        filename='key.json'
        with open(filename) as file_obj:
            key=json.load(file_obj)
        if key!=0:
            atex.insert(INSERT,"KEY HERE:")
        else:
            atex.insert(INSERT,"REGISTERED")

        def a_on_closing():
            global abwinison
            global atex
            
            filename='key.json'
            with open(filename) as file_obj:
                key=json.load(file_obj)
            if key!=0:
                name=atex.get("4.9","4.15")
                
                if key==name:
                    
                    with open(filename,'w') as file_obj:
                        json.dump(0,file_obj)
                    abwinison=0
                    abwin.destroy()
                    
            else:
                abwinison=0
                abwin.destroy()

        abwin.protocol('WM_DELETE_WINDOW', a_on_closing)
def sz():
    global setwinison
    if setwinison==0:
        global setwin
        setwinison=1
        setwin=tkinter.Tk()
        setwin.title("设置")
        setwin.iconbitmap("w10.ico")
        #setwin["background"] = "white"
        setwin.resizable(0,0)
        setwin.geometry("200x300")
        l1=Label(setwin,text='')
        l1.pack()
        global s1
        

        Label(setwin,text='').pack()
        global icl
        csl=Checkbutton(setwin,text="输出运算次数",command=igcl)
        csl.pack()
        Label(setwin,text='').pack()
        crnw=Checkbutton(setwin,text="在新窗口中显示结果",command=rnwi)
        crnw.pack()
        Label(setwin,text='').pack()
        if icl==1:
            csl.select()
        if rnw==1:
            crnw.select()

        def s_on_closing():
            global setwinison
            setwinison=0
            setwin.destroy()


        setwin.protocol('WM_DELETE_WINDOW', s_on_closing)
def stop():
    global stp
    stp=1
def comm(event):
    com()
ifu1=0
def wfct():
    #40,10 
    def clowftc():
        global vfu1,ifu1,vfu2,ifu2
        #print (vfu1.get())
        ifu1=vfu1.get()
        ifu2=vfu2.get()
        bw.destroy()
        fu1.destroy()
        fu2.destroy()
        fi.destroy()
    
    fi=Frame(root,width=180,height=130,bg="whitesmoke")
    fi.grid(row=30,column=10,rowspan=11)
    bw=Button(root,background="whitesmoke",activebackground="whitesmoke",fg='dodgerblue',text='确定',width=20,command=clowftc,relief=FLAT)
    bw.grid(row=40,column=10)
    global vfu1,ifu1,vfu2,ifu2
    
    vfu1=IntVar()
    vfu2=IntVar()
    fu1=Checkbutton(root,text="直接列出质因数",onvalue=1,variable=vfu1)
    fu1.grid(row=30,column=10)
    fu2=Checkbutton(root,text="+输出所有因数",onvalue=1,variable=vfu2)
    fu2.grid(row=36,column=10)
    if ifu1==1:
        fu1.select()

doing=0
def com():
    try:
        global bt
        global doing
        global icl
        doing=1
        global stp
        t="a"
        t=float(e1.get())
        t=int(t)
        if t<2 or t!=float(e1.get()):
            t=0
            退出
        
        bst=Button(root,text='中止',command=stop,relief=GROOVE,width=20,activebackground="pink")
        bst.grid(row=30,column=10)
        #l1.config(text=t)
        #text.destroy()
        global text
        if rnw==1:
            resu=tkinter.Tk()
            resu.title("结果")
            resu.iconbitmap("w10.ico")
            #resu["background"] = "white"
            resu.resizable(0,100)
            resu.geometry("200x300")
            l1=Label(resu,text=t,width=20,font=("Ubuntu",10,"bold"))
            l1.pack()
            text=Text(resu,width=25,height=100,fg='black',bd=0,font=("Ubuntu",10))
            text.pack()
        else:
            
            #text=Text(root,width=22,height=18,fg='black',bd=0,relief=GROOVE,font=("Ubuntu",10))
            #text.grid(row=5,column=20,rowspan=100)
            text.delete(1.0, END)
            text.insert(INSERT,"\n")
            text.insert(INSERT,"\n")
            l1=Label(root,text=t,width=20,bg='white',font=("Ubuntu",10,"bold"))
            l1.grid(row=5,column=20,sticky=N,pady=5)
        a=t
        x=2
        y=0
        z=1
        xz=1
        tried=0
        m=2
        n=0
        p=0
        q=0
        stp=0
        total=math.sqrt(a)
        freq=int(total/20000)+1
        #print(freq)
        #print(ii)
        
        l1=Label(root,text=("最大运算量",int((total-x)/2)),width=20)
        #l1=Label(root,text=(int(x/math.sqrt(a)*100),"％"))
        l1.grid(row=20,column=10)
        root.update()
        while x<=a and stp==0:
            
            tried+=1
            if x**2>a:
                x=int(a)
            while a//x==a/x:
                a=a/x
                total=math.sqrt(a)
                y=y+1
            if y>0:
                #print(x,'^',y,"=",x**y)
                if ifu1==0:
                    text.insert(INSERT,(x,'^',y,"=",x**y))
                    text.insert(INSERT,"\n")
                else:
                    times=y
                    while times:
                        text.insert(INSERT,(x,'/'))
                        times-=1
                

            if y//2==y/2:
                z=z*x**(y//2)
            else:
                xz=x*xz
                z=z*x**(y//2)
            y=0
            if x==2:
                x-=1
            x=x+2
        #print(int((total-x)))
        root.update()
        if  stp==0:
            l1=Label(root,text=("已完成"),width=20)        
            #print("平方根")
            #text.insert(INSERT,"\n")
            #text.insert(INSERT,"平方根:")
            text.insert(INSERT,"\n")
            z=z//1;xz=xz//1
            if z**2==t:
                #print(z)
                text.insert(INSERT,z)
                text.insert(INSERT,"\n")
                
            else:
                text.insert(INSERT,(z,"倍根号",xz))
                text.insert(INSERT,"\n")
                #print(z,xz)
        elif stp==1:
            text.insert(INSERT,"还未分解的因数：")
            text.insert(INSERT,"\n")
            text.insert(INSERT,int(a))
            l1=Label(root,text=("已中止"),width=20)
        l1.grid(row=20,column=10)

        if icl==1:
            text.insert(INSERT,("\n"))
            text.insert(INSERT,("运算次数：",tried))
            
        bst.destroy()
        root.update()
        time.sleep(1)
        l1=Label(root,text=(" "),width=30)
        l1.grid(row=20,column=10)
        root.update()
    except:
        try:
            if t<=0:
                messagebox.showwarning('警告','请输入大于1的整数')
        except:
            messagebox.showwarning('警告','请输入数字')
    doing=0

t=0
stp=0
tmax=5000    
l1=Label(root,text='输入数字',wraplength=0,font=("Ubuntu",15))
l1.grid(row=9,column=10)
root.update()
e1=Entry(root,bd=0,font=("Ubuntu",12),justify='center',
            highlightthickness=2,highlightcolor='dodgerblue',highlightbackground='silver')
e1.grid(row=10,column=10)
empl(20,10)
bt=Button(root,background="whitesmoke",activebackground="whitesmoke",text='获取',command=com,relief=GROOVE,width=20)
bt.grid(row=30,column=10)
e1.bind("<Return>",comm)
text=Text(root,width=22,height=18,fg='black',bd=0,relief=GROOVE,font=("Ubuntu",11),highlightthickness=2,highlightcolor='darkgray',highlightbackground='silver')
text.insert(1.0,"结果将在此显示")
text.grid(row=5,column=20,rowspan=100,sticky=N)
empl(9,30)

bi=Button(root,background="whitesmoke",activebackground="whitesmoke",text='功能选项',fg="grey",width=20,command=wfct,relief=FLAT)
bi.grid(row=40,column=10)

empl(row=60,column=10)

#fi=Frame(root,height=70,width=294,bg="whitesmoke")
#fi.grid(row=70,column=1)

bi=Button(root,background="whitesmoke",activebackground="whitesmoke",text='设置',width=9,command=sz,relief=GROOVE)
bi.grid(row=70,column=10,sticky=W,padx=75)
bi=Button(root,background="whitesmoke",activebackground="whitesmoke",text='关于',width=9,command=abt,relief=GROOVE)
bi.grid(row=70,column=10,sticky=E,padx=75)
def on_closing():
    if doing==1:
        if messagebox.askokcancel("正在进行运算","确实要退出吗?"):
            root.destroy()
    else:
        root.destroy()

root.protocol("WM_DELETE_WINDOW", on_closing)
mainloop()
#pyinstaller -F Watth13.py -w -i C:\Users\jcliu\Documents\scratch\vscode\watth\watth10\w10.ico